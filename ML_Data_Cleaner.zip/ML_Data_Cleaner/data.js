[
    {
        "breaks_taken": 5,
        "sleep_hours": 6.8,
        "label": "Medium"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.75,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.62,
        "label": "Medium"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 5.75,
        "label": "Medium"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.5,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.11,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.82,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.44,
        "label": "Medium"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.62,
        "label": "Medium"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.24,
        "label": "Medium"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.78,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.52,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.73,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.25,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 5.84,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.71,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.77,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.35,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.75,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.98,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 8.25,
        "label": "Medium"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.58,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.88,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 4.83,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.91,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.95,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.09,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 5.3,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.79,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.98,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 8.21,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.5,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.63,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 8.02,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.3,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.51,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.02,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.71,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.53,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.06,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.19,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.65,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.76,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 5.17,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.23,
        "label": "Medium"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.47,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.61,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.72,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 8.12,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.15,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 5.69,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.67,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.14,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.89,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 8.3,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.55,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.46,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.74,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.64,
        "label": "Medium"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 9.59,
        "label": "Medium"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.08,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 5.58,
        "label": "Medium"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 8,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.54,
        "label": "Medium"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.94,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.89,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.46,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.36,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.45,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 8.32,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 8.05,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.27,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 5.55,
        "label": "Medium"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 5.56,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 5.13,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.74,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.59,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 5.34,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 8.08,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 8.34,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.77,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.94,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 5.37,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.66,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.53,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.65,
        "label": "Medium"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 8.53,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 5.71,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.36,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 9.85,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.4,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.7,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.96,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.46,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.67,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.07,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.03,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.05,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7,
        "label": "Medium"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.88,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.42,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 5.85,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.15,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.26,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.37,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.66,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 5.55,
        "label": "Medium"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.86,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.79,
        "label": "Medium"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 8.1,
        "label": "Medium"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 8.14,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 5.49,
        "label": "Medium"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.83,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.59,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 5.75,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 9.11,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 5.69,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.86,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 5.51,
        "label": "Medium"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 5.15,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.22,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 5.69,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.13,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.82,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.62,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.12,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.88,
        "label": "Medium"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 4.62,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.82,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.36,
        "label": "Medium"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.22,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.24,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.42,
        "label": "Medium"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 4.6,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.52,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 5.19,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.36,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.68,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 8.44,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 5.49,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.23,
        "label": "Medium"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 5.86,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.51,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 5.94,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.91,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.08,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.07,
        "label": "Medium"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.11,
        "label": "Medium"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.38,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.69,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.55,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.19,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 4.71,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 8.14,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 5.95,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.47,
        "label": "Medium"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 5.98,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.25,
        "label": "Medium"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.9,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 5.96,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.07,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.27,
        "label": "Medium"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.68,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.67,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.95,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 8.78,
        "label": "Medium"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.57,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.98,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 5.94,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.3,
        "label": "Medium"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.8,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.36,
        "label": "High"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.82,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.22,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 8,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.67,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.53,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 4.64,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.74,
        "label": "Medium"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.52,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.93,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.77,
        "label": "High"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.23,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.25,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 8.62,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.08,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.31,
        "label": "Medium"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 8.53,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.41,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.49,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.24,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7,
        "label": "Medium"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.87,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 8.58,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 8.79,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.33,
        "label": "Medium"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.34,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 5.76,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 9.76,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.97,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 9.27,
        "label": "Medium"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.96,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.66,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.34,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 8.01,
        "label": "Medium"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 8.08,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 5.95,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.29,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.26,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 4.81,
        "label": "Medium"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.69,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.86,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.08,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.33,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.93,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.51,
        "label": "Medium"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.91,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.78,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.92,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 8.35,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 8.22,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.38,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.47,
        "label": "Medium"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.34,
        "label": "Medium"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.74,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.2,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.87,
        "label": "Medium"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.71,
        "label": "Medium"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.26,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 5.38,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.35,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.68,
        "label": "Medium"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.09,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 4.76,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.73,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 5.61,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 5.69,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 8.07,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.64,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 8.73,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 5.26,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.56,
        "label": "Medium"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 8.72,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.34,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.62,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.58,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 5.45,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.77,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.23,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.12,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.71,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 8.39,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.44,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 5.03,
        "label": "Medium"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.77,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.09,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.9,
        "label": "Medium"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.93,
        "label": "Medium"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.26,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.81,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.36,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.49,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.55,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 9.47,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.63,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 8.67,
        "label": "Medium"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.77,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.54,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 9.1,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.25,
        "label": "Medium"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 5.6,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 8.05,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 4.96,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.26,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.11,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 8.56,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 5.3,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.64,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 5.27,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 8.29,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.3,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.58,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.07,
        "label": "Medium"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.43,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.13,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.8,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.16,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.77,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 5.59,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 5.72,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.68,
        "label": "Medium"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 4.57,
        "label": "Medium"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.22,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.37,
        "label": "Medium"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.98,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.28,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.52,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.23,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.87,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.54,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 5.23,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 8.94,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.11,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.56,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 5.44,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 5.8,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.92,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 5.89,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 5.88,
        "label": "Medium"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.1,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.69,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.33,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.95,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.55,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.2,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.89,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 5.87,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 8.6,
        "label": "Medium"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.38,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.42,
        "label": "Medium"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.8,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.31,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 8.55,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.86,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.92,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.69,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.04,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.51,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 8.25,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.83,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 9.42,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.27,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.16,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.03,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.87,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 8.59,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.31,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.04,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.76,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.12,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 8.12,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.23,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.02,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.24,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.29,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 5.88,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.06,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 8.9,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.36,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.52,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.63,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.62,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 8.11,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.49,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 8.47,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 4.89,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 5.87,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 5.16,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.46,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 8.33,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.48,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.65,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.31,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.94,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.6,
        "label": "Medium"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 8.02,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 5.96,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 8.14,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.04,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.57,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.18,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.37,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 4.5,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.91,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 8.73,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.81,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 4.5,
        "label": "Medium"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.05,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.02,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 8.54,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.9,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.83,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 5.54,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.99,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 5.97,
        "label": "Medium"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 4.81,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 8.28,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.58,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.3,
        "label": "Medium"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 5.5,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 8.2,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 4.68,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.73,
        "label": "Medium"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.31,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.26,
        "label": "High"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 8.75,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.57,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.42,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 8.73,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.25,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 9.09,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 9.04,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.69,
        "label": "Medium"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 5.37,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.36,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 8.01,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.82,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.1,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 5.01,
        "label": "Medium"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 5.72,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.21,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.23,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.83,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.04,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.26,
        "label": "Medium"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.73,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 8.06,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.8,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.59,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.77,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 8.26,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 5.45,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 5.34,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.02,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 8.53,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.7,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 5.56,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.91,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 5.08,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.25,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.15,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.73,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.09,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.88,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.07,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.34,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 5.83,
        "label": "Medium"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.87,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.4,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.06,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.53,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.4,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 5.34,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.53,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 5.19,
        "label": "Medium"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 8.35,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.58,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 5.42,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.43,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.08,
        "label": "Medium"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.16,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 8.35,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.81,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.74,
        "label": "Medium"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.98,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 4.7,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 8.78,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 8.94,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.42,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 5.84,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.28,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.51,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.98,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.95,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.74,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 5.01,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.63,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.07,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.03,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.92,
        "label": "Medium"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.35,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.28,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 8.01,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.58,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.04,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.75,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.33,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.11,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 8.45,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.84,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.89,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.63,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.91,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 8.84,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.79,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.63,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.03,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.56,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 5.52,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.54,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.87,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 4.5,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 5.66,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.17,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.5,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.44,
        "label": "Medium"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 9.73,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.58,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 4.92,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.1,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.89,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 5.63,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.6,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 4.93,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.23,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.33,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 9.82,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.1,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.06,
        "label": "Medium"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 8.81,
        "label": "Medium"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.55,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.85,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.44,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 5.18,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.21,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 5.89,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.32,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 5.64,
        "label": "Medium"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 5.7,
        "label": "Medium"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 8.21,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 8.28,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.3,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.47,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 5.72,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 4.93,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.72,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.39,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 9.46,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.01,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.93,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 5.24,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.58,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.99,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 5.95,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.76,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 8.13,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.7,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.27,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 8.06,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.9,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.97,
        "label": "Medium"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.33,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.07,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.94,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.91,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 5.62,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.97,
        "label": "Medium"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 8.41,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.39,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.83,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.27,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 5.89,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.97,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 5.73,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 9.4,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 8.91,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.64,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 9.52,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 5.27,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.36,
        "label": "High"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.27,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 9.06,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 8.25,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.53,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 5.89,
        "label": "Medium"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 8.45,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.69,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.55,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.57,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 5.24,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.78,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.93,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.53,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.82,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.14,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 5.69,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 5.46,
        "label": "Medium"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.42,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 8.64,
        "label": "Medium"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.48,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 5.78,
        "label": "Medium"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.39,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 5.65,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 5.85,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.85,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.1,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.22,
        "label": "Medium"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 8.65,
        "label": "High"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 8.22,
        "label": "Medium"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.49,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.07,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 5.81,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 8.11,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.24,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.91,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.86,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.85,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.73,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.02,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 9.1,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 5.83,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 5.96,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.83,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 4.94,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 8.37,
        "label": "Medium"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.38,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 4.74,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.78,
        "label": "Medium"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.25,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.64,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 8.76,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 5.01,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.63,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.41,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 8.1,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 8.78,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.53,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 5.04,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 8.33,
        "label": "Medium"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.35,
        "label": "Medium"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.55,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.54,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.32,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.41,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.41,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 9.04,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.04,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.56,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.8,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.81,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.76,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 9.57,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.1,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 9.49,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.64,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.29,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.28,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 4.91,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 4.5,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 8.12,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 5.57,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 8.01,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.06,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.95,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.75,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.02,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.39,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.04,
        "label": "Medium"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.9,
        "label": "High"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.34,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.24,
        "label": "High"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.59,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 8.14,
        "label": "Medium"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 10.21,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 4.8,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 8.09,
        "label": "Medium"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.7,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.97,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.48,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.9,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.74,
        "label": "Medium"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.67,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 8.08,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 8.91,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.31,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 5.95,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 8.08,
        "label": "Medium"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 8.69,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.1,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 8.07,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.38,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.83,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.08,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.36,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.45,
        "label": "Medium"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.74,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 8.07,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.72,
        "label": "Medium"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.67,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.66,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.61,
        "label": "Medium"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.37,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 8.79,
        "label": "High"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 5.86,
        "label": "High"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.68,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 5.46,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.22,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.26,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.94,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.28,
        "label": "Medium"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.08,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 5.69,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.86,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 5.77,
        "label": "Medium"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 10.8,
        "label": "Medium"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.54,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 4.5,
        "label": "Medium"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.21,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.57,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.58,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.84,
        "label": "Medium"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 8.04,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 8.41,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.19,
        "label": "Medium"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.38,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.28,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 8.96,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 8.18,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 5.67,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.64,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.19,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 5.92,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 8.13,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 9.9,
        "label": "Medium"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.27,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.46,
        "label": "Medium"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.98,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 9.31,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.01,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.53,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 8.62,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.67,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.17,
        "label": "Medium"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.78,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 8.24,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 4.6,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 8.33,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.53,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 5.98,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.81,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 8.07,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.95,
        "label": "Medium"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 8.57,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.64,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.3,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 8.71,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.43,
        "label": "Medium"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.54,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.58,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 5.68,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.22,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.42,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.38,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.38,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.42,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 8.88,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 8.51,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 5.93,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 8.3,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.05,
        "label": "Medium"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 8.32,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 8.2,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.98,
        "label": "Medium"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 5.06,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.78,
        "label": "Medium"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 8.87,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.24,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.42,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.62,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 8.93,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.24,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.88,
        "label": "Medium"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 5.72,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.15,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.12,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 8,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 5.87,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.18,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.15,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.61,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.37,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 8.94,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 5.09,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 5.17,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.72,
        "label": "Medium"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.86,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.9,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.2,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 4.76,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 8.85,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 8.21,
        "label": "Medium"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.94,
        "label": "High"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.6,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 5.56,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 5.54,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 9,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 8.02,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 8.52,
        "label": "Medium"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.73,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 8.97,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 5.02,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.11,
        "label": "Medium"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.46,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 5.7,
        "label": "High"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.05,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.43,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.76,
        "label": "Medium"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.07,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 5.08,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.11,
        "label": "Medium"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.65,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.8,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 5.74,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.63,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.53,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.61,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.72,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.6,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.85,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.75,
        "label": "Medium"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 4.5,
        "label": "Medium"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 5.88,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 5.31,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 8.82,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 8.25,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.51,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.83,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.17,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.25,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 8.54,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.04,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.02,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.32,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.92,
        "label": "Medium"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.6,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.56,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.46,
        "label": "High"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 5.96,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.52,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.23,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.43,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 5.82,
        "label": "Medium"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 9.86,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.9,
        "label": "Medium"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.87,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.88,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 8.24,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.77,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 5.07,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.22,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.3,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.98,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.56,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.06,
        "label": "Medium"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.8,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.87,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 4.5,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.65,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.91,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.95,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.93,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 5.11,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.21,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.38,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.78,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.76,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.33,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 8,
        "label": "Medium"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 5.95,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 8.16,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 9.16,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.21,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 5.44,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.26,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 5.26,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.85,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.54,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.18,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.01,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.08,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 5.1,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 9.8,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 5.01,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.12,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 8.06,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.66,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 5.1,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 5.89,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.75,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.39,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 5.91,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.55,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.02,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.98,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.45,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.94,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.3,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 5.03,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.46,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 8.12,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 8.18,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.09,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.38,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.55,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 5.96,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 8.07,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 8.53,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.17,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.53,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.77,
        "label": "Medium"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.03,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.5,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.54,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.81,
        "label": "Medium"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.73,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 8.41,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.53,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.23,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.03,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 5.68,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.26,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.18,
        "label": "Medium"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 5.8,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.29,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.94,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 5.49,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 5.79,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.95,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 5.66,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.87,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.6,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 7.32,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.01,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.81,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.61,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.51,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.32,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.06,
        "label": "Medium"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.91,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 4.5,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.78,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.64,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.16,
        "label": "Medium"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.37,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.56,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 5.63,
        "label": "Medium"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 8.83,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 8.18,
        "label": "Medium"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.63,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 8.96,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.09,
        "label": "Medium"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.39,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.21,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.19,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 8.72,
        "label": "Medium"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 5.7,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 8.4,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.23,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.55,
        "label": "Medium"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.49,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.53,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.98,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.99,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 5.83,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 5.76,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.93,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 7.5,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 8.25,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.51,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.72,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 5.74,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.97,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.5,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.17,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.75,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 7.8,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 5.48,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.98,
        "label": "High"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 8.16,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 8,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 8.21,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 5.48,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.6,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 8.58,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.08,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.25,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.61,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 8.34,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.1,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.99,
        "label": "Medium"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 6.12,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.22,
        "label": "Low"
    },
    {
        "breaks_taken": 3,
        "sleep_hours": 6.58,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 5.14,
        "label": "Low"
    },
    {
        "breaks_taken": 2,
        "sleep_hours": 7.22,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 7.82,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 8.05,
        "label": "Medium"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 4.65,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 5.87,
        "label": "Low"
    },
    {
        "breaks_taken": 5,
        "sleep_hours": 6.62,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 8.92,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 9.32,
        "label": "Low"
    },
    {
        "breaks_taken": 1,
        "sleep_hours": 6.17,
        "label": "Low"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 8.43,
        "label": "High"
    },
    {
        "breaks_taken": 4,
        "sleep_hours": 6.25,
        "label": "Low"
    }
]